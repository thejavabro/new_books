/* Auto-playing 16:9 chapter animation. Everything on screen is a function of time, so it can be paused, scrubbed and filmed. */
(function(){
const SPEC=window.SPEC,W=1920,H=1080,X0=120,CW=1680,Y0=270,CH=600;
const C={blue:'#5aa9ff',amber:'#ffb454',green:'#4ade80',red:'#ff6b6b',violet:'#b794f6',teal:'#2dd4bf',muted:'#8fa3bf'};
const CY=['blue','amber','green','violet','teal','red'];
const col=c=>C[c]||C.blue;
const clamp=(x,a,b)=>Math.max(a==null?0:a,Math.min(b==null?1:b,x));
const eo=p=>1-Math.pow(1-p,3),eio=p=>p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;
const back=p=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(p-1,3)+c1*Math.pow(p-1,2)};
const pr=(t,at,d)=>clamp((t-at)/(d||.7));
function rng(s){return function(){s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const st=(o)=>Object.keys(o).map(k=>k+':'+(typeof o[k]==='number'&&!/opacity|z-index|flex|font-weight/.test(k)?o[k]+'px':o[k])).join(';');
const box=(cls,x,y,w,h,inner,a,extra)=>`<div class="${cls}" style="left:${x}px;top:${y}px;width:${w}px;${h?`height:${h}px;`:''}${extra||''}"${a?` data-a="${a}"`:''}>${inner}</div>`;
const fmt=(v,dec)=>dec?v.toFixed(dec):Math.round(v).toLocaleString('en-US');

const DUR={title:s=>7.5,points:s=>3.5+s.items.length*2.7,stats:s=>5+s.items.length*1.7,bars:s=>5+s.items.length*1.3,flow:s=>6.5+s.nodes.length*1.1,
 versus:s=>5.5+(s.a.items.length+s.b.items.length)*1.25,pipeline:s=>4.5+s.stages.length*2.3,cycle:s=>5+s.items.length*2.6,lanes:s=>11,curve:s=>11,scatter:s=>11,
 stack:s=>3.5+s.levels.length*2.5,units:s=>6+s.groups.length*1.8,verdicts:s=>2.5+s.items.length*2.8,quote:s=>3.5+s.text.split(' ').length*.3,recap:s=>4.5+s.items.length*1.6,outro:s=>7};

/* ---------- scene builders: return html; register time functions with S.fn(at,dur,f) / S.loop(f) ---------- */
const B={};
B.title=(s,S)=>{
  const words=s.title.split(' ');
  S.loop((t,g)=>{g('rings').style.transform=`rotate(${t*14}deg)`;g('rings2').style.transform=`rotate(${-t*9}deg)`});
  return `<svg class="lay"><g transform="translate(1480 540)"><g id="${S.id}rings" style="transform-origin:0 0"><circle r="330" fill="none" stroke="${S.acc}" stroke-width="3" stroke-dasharray="1" pathLength="1" data-a="draw,.2,2.2" opacity=".5"/><circle r="330" cx="0" cy="0" fill="none" stroke="${S.acc}" stroke-width="14" stroke-dasharray="6 60" opacity=".35"/><circle cx="330" r="16" fill="${S.acc}"/></g>
  <g id="${S.id}rings2" style="transform-origin:0 0"><circle r="430" fill="none" stroke="#33456a" stroke-width="3" stroke-dasharray="14 22"/><circle cx="-430" r="11" fill="${C.amber}"/><circle cy="430" r="8" fill="${C.teal}"/></g></g></svg>`
  +box('bigN',1480-360,540-300,720,600,s.n,'pop,.3,1.1','text-align:center;'+((String(s.n).length>3||String(s.n).indexOf("–")>0)?'font-size:200px;padding-top:190px;white-space:nowrap;':String(s.n).length>1?'font-size:400px;padding-top:70px;':''))
  +box('',120,300,1100,0,`<i style="display:inline-block;width:60px;height:6px;background:${S.acc};vertical-align:middle;margin-right:20px"></i>${s.part||''}`,'left,.5','font-size:32px;letter-spacing:.2em;text-transform:uppercase;color:#8fa3bf;font-weight:600;')
  +`<div style="left:120px;top:370px;width:${s.title.length>30||(String(s.n).length>3||String(s.n).indexOf("–")>0)?1000:1150}px;font-size:${s.title.length>30?84:s.title.length>14?100:118}px;font-weight:800;line-height:1.04;letter-spacing:-.025em">${words.map((w,i)=>`<span style="display:inline-block;margin-right:.25em" data-a="up,${(.9+i*.14).toFixed(2)},.8">${w}</span>`).join('')}</div>`
  +box('',120,720,1100,0,s.sub||'','up,2.1','font-size:42px;line-height:1.3;color:#c9d6ea;')
  +box('',120,950,1400,0,SPEC.credit,'fade,2.8','font-size:25px;color:#8fa3bf;letter-spacing:.04em;');
};
B.points=(s,S)=>{
  const n=s.items.length,cols=n<=4?n:Math.ceil(n/2),rows=n<=4?1:2,gap=28,w=(CW-gap*(cols-1))/cols,h=rows===1?540:286,step=(S.T-3)/n;
  const fs=rows===1?(cols===4?[38,29]:cols===3?[46,34]:[56,40]):[32,25];
  return s.items.map((it,i)=>{const x=X0+(i%cols)*(w+gap),y=Y0+Math.floor(i/cols)*(h+gap),at=1+i*step,c=col(it.c||CY[i%6]);
    S.fn(at,step,(p,t,g)=>{const e=g('c'+i),on=t>=at&&t<at+step;e.style.borderColor=on?c:'#26344d';e.style.boxShadow=on?`0 0 ${40+Math.sin(t*5)*14}px ${c}55`:'none'},null,true);
    return box('card',x,y,w,h,`<div class="bar"></div><div class="num">${it.n||i+1}</div><h3 style="font-size:${fs[0]}px">${it.t}</h3><p style="font-size:${fs[1]}px">${it.d||''}</p>`,`pop,${at.toFixed(2)},.7`,`--c:${c}`).replace('<div class="card"',`<div id="${S.id}c${i}" class="card"`)}).join('');
};
B.stats=(s,S)=>{
  const n=s.items.length,w=CW/n;
  return `<svg class="lay">${s.items.map((it,i)=>`<circle cx="${X0+w*(i+.5)}" cy="${Y0+230}" r="${Math.min(210,w/2-30)}" fill="none" stroke="${col(it.c||CY[i])}" stroke-width="10" stroke-linecap="round" stroke-dasharray="1" pathLength="1" data-a="draw,${(.8+i*1.2).toFixed(2)},1.6"/><circle id="${S.id}o${i}" r="13" fill="${col(it.c||CY[i])}"/>`).join('')}</svg>`
  +s.items.map((it,i)=>{const at=.8+i*1.2,c=col(it.c||CY[i]),R=Math.min(210,w/2-30),cx=X0+w*(i+.5),cy=Y0+230;
    S.fn(at,1.6,(p,t,g)=>{g('v'+i).textContent=(it.pre||'')+fmt(it.v*eo(p),it.dec)+(it.suf||'')});
    S.loop((t,g)=>{const a=t*.9+i;const o=g('o'+i);o.setAttribute('cx',cx+Math.cos(a)*R);o.setAttribute('cy',cy+Math.sin(a)*R);o.style.opacity=t>at+1.6?1:0});
    return box('big',X0+w*i,Y0+230-(n>3?55:70),w,0,`<span id="${S.id}v${i}"></span>`,`pop,${at},.6`,`text-align:center;white-space:nowrap;font-size:${((it.pre||'')+it.v+(it.suf||'')).length>4?82:(n>3?108:132)}px;line-height:${n>3?108:132}px;color:${c};`)
     +box('lbl',X0+w*i+20,Y0+470,w-40,0,it.l,`up,${at+.7},.6`,`text-align:center;font-size:${n>3?30:34}px;`)}).join('');
};
B.bars=(s,S)=>{
  const n=s.items.length,rh=Math.min(120,CH/n),max=s.max||Math.max(...s.items.map(i=>i.v)),lw=s.lw||470,tw=CW-lw-270;
  return s.items.map((it,i)=>{const y=Y0+i*rh+(CH-n*rh)/2,at=1+i*.8,c=col(it.c||'blue'),bh=Math.min(58,rh-34);
    S.fn(at,1.4,(p,t,g)=>{const e=eo(p);g('f'+i).style.width=(tw*it.v/max*e)+'px';g('v'+i).textContent=it.txt!=null?(p>.6?it.txt:''):(it.pre||'')+fmt(it.v*e,it.dec)+(it.suf||'')});
    return box('',X0,y,lw-30,rh,`<div style="font-size:${rh<90?28:33}px;font-weight:650;line-height:1.15">${it.l}</div>`,`left,${at},.6`,'display:flex;align-items:center;justify-content:flex-end;text-align:right;')
    +box('',X0+lw,y+(rh-bh)/2,tw,bh,`<div id="${S.id}f${i}" style="height:100%;width:0;border-radius:12px;background:linear-gradient(90deg,${c}aa,${c});box-shadow:0 0 30px ${c}66"></div>`,`fade,${at},.4`,'background:#131d30;border-radius:12px;')
    +box('big',X0+lw+tw+24,y,246,rh,`<span id="${S.id}v${i}"></span>`,`fade,${at},.4`,`display:flex;align-items:center;font-size:${it.txt!=null?32:(rh<90?40:50)}px;line-height:1.1;letter-spacing:0;color:${c};`)}).join('')
  +(s.note?box('',X0,Y0+CH+2,CW,0,s.note,`fade,${1+n*.8}`,'text-align:right;font-size:23px;color:#8fa3bf;'):'');
};
B.flow=(s,S)=>{
  const cols=s.cols||Math.max(...s.nodes.map(n=>n.col))+1,rows=s.rows||Math.max(...s.nodes.map(n=>n.row))+1,nw=Math.min(380,CW/cols-70),nh=Math.min(120,CH/rows-36);
  const N={},step=Math.min(.8,(S.T-5)/s.nodes.length);
  s.nodes.forEach((n,i)=>{n.x=X0+(n.col+.5)*CW/cols;n.y=Y0+(n.row+.5)*CH/rows;n.at=.9+i*step;N[n.id]=n});
  const clip=(n,ux,uy)=>{const hw=nw/2+10,hh=nh/2+10,t=Math.min(ux?hw/Math.abs(ux):1e9,uy?hh/Math.abs(uy):1e9);return[n.x+ux*t,n.y+uy*t]};
  let svg='';
  s.edges.forEach((e,k)=>{const a=N[e[0]],b=N[e[1]],dx=b.x-a.x,dy=b.y-a.y,L=Math.hypot(dx,dy),ux=dx/L,uy=dy/L,p=clip(a,ux,uy),q=clip(b,-ux,-uy),c=e[2]?C.red:'#7f97bb',at=Math.max(a.at,b.at)+.35;
    svg+=`<line x1="${p[0]}" y1="${p[1]}" x2="${q[0]-ux*14}" y2="${q[1]-uy*14}" stroke="${c}" stroke-width="5" stroke-linecap="round" pathLength="1" stroke-dasharray="1" data-a="draw,${at.toFixed(2)},.6"/><polygon points="${q[0]},${q[1]} ${q[0]-ux*24-uy*12},${q[1]-uy*24+ux*12} ${q[0]-ux*24+uy*12},${q[1]-uy*24-ux*12}" fill="${c}" data-a="pop,${(at+.5).toFixed(2)},.3"/>`
    +[0,1].map(j=>`<circle id="${S.id}p${k}_${j}" r="8" fill="${e[2]?C.red:col(a.c)}" opacity="0"/>`).join('')
    +(e[2]&&e[2]!==2?`<text x="${(p[0]+q[0])/2-uy*26}" y="${(p[1]+q[1])/2+ux*26+12}" text-anchor="middle" font-size="44" font-weight="800" fill="${C.red}" data-a="pop,${at+.5}">−</text>`:'');
    S.loop((t,g)=>{[0,1].forEach(j=>{const o=g('p'+k+'_'+j),f=((t-at)*.45+j*.5)%1;if(t<at+.6){o.setAttribute('opacity',0);return}o.setAttribute('cx',p[0]+(q[0]-p[0])*f);o.setAttribute('cy',p[1]+(q[1]-p[1])*f);o.setAttribute('opacity',Math.sin(f*Math.PI))})})});
  return `<svg class="lay">${svg}</svg>`+s.nodes.map(n=>box('node',n.x-nw/2,n.y-nh/2,nw,nh,n.t,`pop,${n.at.toFixed(2)},.6`,`--c:${col(n.c)};font-size:${rows>=5?(n.big?27:24):(n.big?34:29)}px;${n.big?'background:'+col(n.c)+'22;':''}`)).join('');
};
B.versus=(s,S)=>{
  const pw=800,na=s.a.items.length,nb=s.b.items.length,stp=Math.min(1.25,(S.T-4)/(na+nb)),tb=1.2+na*stp+.8;
  const pan=(o,x,t0,dc,id)=>box('pan',x,Y0,pw,CH,`<div class="ph">${o.h}</div><div style="padding:30px 34px;display:flex;flex-direction:column;gap:${o.items.length>4?18:30}px;font-size:${o.items.length>4?31:36}px">${o.items.map((r,i)=>`<div class="row" data-a="${x<900?'left':'right'},${(t0+.5+i*stp).toFixed(2)},.6"><i></i><span>${r}</span></div>`).join('')}</div>`,`up,${t0},.7`,`--c:${col(o.c||dc)}`).replace('<div class="pan"',`<div id="${S.id}${id}" class="pan"`);
  S.fn(tb,.8,(p,t,g)=>{g('A').style.filter=`saturate(${1-.7*p}) brightness(${1-.35*p})`;g('B').style.boxShadow=`0 0 ${70*p}px ${col(s.b.c||'green')}55`});
  S.loop((t,g)=>{g('vs').style.transform=`rotate(${Math.sin(t*1.3)*6}deg) scale(${1+Math.sin(t*2.6)*.04})`});
  return pan(s.a,X0,.7,'red','A')+pan(s.b,X0+pw+80,tb,'green','B')
   +box('',X0+pw-20,Y0+CH/2-60,120,120,`<div id="${S.id}vs" style="width:120px;height:120px;border-radius:50%;background:#0a101c;border:4px solid ${S.acc};display:grid;place-items:center;font-weight:900;font-size:40px;color:${S.acc}">${s.mid||'VS'}</div>`,`pop,${(tb-.4).toFixed(2)},.6`);
};
B.pipeline=(s,S)=>{
  const n=s.stages.length,w=CW/n,step=(S.T-4.5)/n,y=Y0+70,times=s.stages.map((_,i)=>1.6+i*step),stop=s.stop;
  S.loop((t,g)=>{let x=X0+w*.5,i=0;for(;i<n-1;i++){if(t<times[i+1]){x+=w*i+w*eio(clamp((t-times[i]-step*.55)/(step*.45)));break}}if(i===n-1)x+=w*(n-1);
    let bad=false;if(stop!=null&&t>=times[stop]){bad=true;x=X0+w*(stop+.5)+Math.sin(t*30)*Math.max(0,1-(t-times[stop]))*10}
    const tk=g('tk');tk.style.left=(x-26)+'px';tk.style.opacity=t>1.2?1:0;tk.style.background=bad?C.red:(s.tc?col(s.tc):'#fff');tk.style.transform=`scale(${1+Math.sin(t*6)*.12})`;
    s.stages.forEach((sg,k)=>{const on=t>=times[k]&&(stop==null||k<=stop),c=bad&&k===stop?C.red:col(sg.c||CY[k%6]);const e=g('s'+k);e.style.background=on?c:'#1a2640';e.style.color=on?'#0a101c':'#8fa3bf';e.style.transform=`translateY(${on?-10*Math.max(0,1-(t-times[k])*2):0}px)`})});
  return s.stages.map((sg,i)=>box('stg',X0+i*w,y,w+22,150,sg.t,`left,${(.5+i*.15).toFixed(2)},.5`,'background:#1a2640;color:#8fa3bf;').replace('<div class="stg"',`<div id="${S.id}s${i}" class="stg"`)
    +box('sd',X0+i*w+14,y+250,w-28,0,sg.d||'',`up,${(times[i]+.15).toFixed(2)},.6`)
    +(stop===i?box('stamp',X0+i*w+w/2-120,y-110,240,70,s.stopLabel||'caught here',`stamp,${(times[i]+.3).toFixed(2)},.4`,`--c:${C.red};font-size:27px;white-space:nowrap;background:#0a101c;`):'')).join('')
   +`<div id="${S.id}tk" style="top:${y+178}px;width:52px;height:52px;border-radius:50%;box-shadow:0 0 30px #fff8"></div>`
   +`<svg class="lay"><line x1="${X0+w*.5}" y1="${y+204}" x2="${X0+CW-w*.5}" y2="${y+204}" stroke="#33456a" stroke-width="4" stroke-dasharray="4 14" stroke-linecap="round"/></svg>`
   +(s.note?box('',X0,Y0+CH-70,CW,0,s.note,`up,${(S.T-3).toFixed(2)}`,`text-align:center;font-size:36px;font-weight:700;color:${S.acc};`):'');
};
B.cycle=(s,S)=>{
  const n=s.items.length,cx=560,cy=Y0+CH/2,R=235,step=(S.T-5)/n,times=s.items.map((_,i)=>1.8+i*step),ang=i=>-Math.PI/2+i*2*Math.PI/n;
  S.loop((t,g)=>{let a;const end=times[n-1]+step*.6;if(t<times[0])a=ang(0);else if(t>=end)a=ang(n-1)+(t-end)*2.2;else{let i=Math.min(n-2,Math.floor((t-times[0])/step));a=ang(i)+(ang(1)-ang(0))*eio(clamp((t-times[i]-step*.5)/(step*.5)))}
    const m=g('m');m.setAttribute('cx',cx+Math.cos(a)*R);m.setAttribute('cy',cy+Math.sin(a)*R);m.setAttribute('opacity',t>1.4?1:0);
    s.items.forEach((it,k)=>{const on=t>=times[k]&&(k===n-1||t<times[k+1]),e=g('n'+k),c=col(it.c||CY[k%6]);e.style.background=t>=times[k]?c:'#101a2c';e.style.color=t>=times[k]?'#0a101c':'#eef3fb';e.style.boxShadow=on?`0 0 50px ${c}`:'none';g('d'+k).style.opacity=t<times[k]?0:(on?1:.5)})});
  return `<svg class="lay"><circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#33456a" stroke-width="6" pathLength="1" stroke-dasharray="1" data-a="draw,.5,1.3"/><circle id="${S.id}m" r="20" fill="#fff" style="filter:drop-shadow(0 0 14px #fff)"/></svg>`
   +box('',cx-130,cy-60,260,120,s.center||'',`pop,.9`,`display:grid;place-items:center;text-align:center;font-size:32px;font-weight:800;color:${S.acc};line-height:1.15;`)
   +s.items.map((it,i)=>{const x=cx+Math.cos(ang(i))*R,y=cy+Math.sin(ang(i))*R,c=col(it.c||CY[i%6]);
     return box('',x-105,y-46,210,92,it.t,`pop,${(.7+i*.15).toFixed(2)},.5`,`border:3px solid ${c};border-radius:46px;display:grid;place-items:center;text-align:center;font-weight:800;font-size:${it.t.length>12?24:29}px;line-height:1.05;background:#101a2c;`).replace('<div class=""',`<div id="${S.id}n${i}"`)
      +`<div id="${S.id}d${i}" style="left:1010px;top:${Y0+i*(CH/n)}px;width:790px;height:${CH/n-14}px;display:flex;flex-direction:column;justify-content:center;border-left:8px solid ${c};padding-left:26px;opacity:0;transition:opacity .4s"><div style="font-size:${n>4?30:34}px;font-weight:800;color:${c}">${i+1}. ${it.t}</div><div style="font-size:${n>4?24:27}px;color:#c9d6ea;line-height:1.3">${it.d||''}</div></div>`}).join('');
};
B.lanes=(s,S)=>{
  const n=s.lanes.length,lh=Math.min(170,(CH-(s.note?70:0))/n),rx=X0+420,rw=CW-420-240,t0=1.6,t1=S.T-2.6;
  S.loop((t,g)=>{const f=clamp((t-t0)/(t1-t0));s.lanes.forEach((l,i)=>{const cnt=Math.floor(l.n*f+1e-6);g('r'+i).style.left=(rx+rw*f-18)+'px';g('r'+i).style.opacity=t>t0-.4?1:0;g('k'+i).textContent=(l.fmt?l.fmt(f):cnt)+(l.suf||'');
    for(let j=0;j<l.n&&j<200;j++){const tj=t0+(j+1)/l.n*(t1-t0)-.001,p=clamp((t-tj)/.35),e=g('t'+i+'_'+j);e.style.opacity=p>0?1:0;e.style.transform=`scaleY(${p<=0?0:back(p)})`}})});
  return s.lanes.map((l,i)=>{const y=Y0+i*lh+(CH-(s.note?70:0)-n*lh)/2,c=col(l.c||CY[i]);let ticks='';
    for(let j=0;j<l.n&&j<200;j++){const bad=l.fail&&(j%l.fail===l.fail-1);ticks+=`<i id="${S.id}t${i}_${j}" style="position:absolute;left:${((j+1)/l.n*100).toFixed(2)}%;margin-left:-${l.n>30?5:8}px;top:14px;bottom:14px;width:${l.n>30?10:16}px;border-radius:5px;background:${bad?C.red:c};opacity:0"></i>`}
    return box('',X0,y,390,lh-20,`<div><div style="font-size:36px;font-weight:800;color:${c}">${l.l}</div><div style="font-size:25px;color:#8fa3bf">${l.d||''}</div></div>`,`left,${.6+i*.3}`,'display:flex;align-items:center;')
     +box('',rx,y+10,rw,lh-40,ticks,`fade,${.8+i*.3}`,'background:#0f1828;border:2px solid #26344d;border-radius:16px;')
     +`<div id="${S.id}r${i}" style="top:${y+(lh-20)/2-18}px;width:36px;height:36px;border-radius:50%;background:#fff;box-shadow:0 0 24px ${c};opacity:0"></div>`
     +box('big',rx+rw+30,y,210,lh-20,`<span id="${S.id}k${i}">0</span>`,`fade,1`,`display:flex;align-items:center;font-size:76px;color:${c};`)}).join('')
   +(s.note?box('',X0,Y0+CH-58,CW,0,s.note,`up,${(S.T-3.2).toFixed(2)}`,`text-align:center;font-size:34px;font-weight:700;color:${S.acc};`):'');
};
B.curve=(s,S)=>{
  const px=X0+110,py=Y0+10,pw=s.legend===false?CW-200:1060,ph=CH-90,X=v=>px+v*pw,Y=v=>py+ph-v*ph;let svg='';
  svg+=`<line x1="${px}" y1="${py+ph}" x2="${px+pw}" y2="${py+ph}" stroke="#5a6f93" stroke-width="4" pathLength="1" stroke-dasharray="1" data-a="draw,.4,.8"/><line x1="${px}" y1="${py+ph}" x2="${px}" y2="${py}" stroke="#5a6f93" stroke-width="4" pathLength="1" stroke-dasharray="1" data-a="draw,.4,.8"/>`;
  for(let i=1;i<5;i++)svg+=`<line x1="${px}" y1="${Y(i/4)}" x2="${px+pw}" y2="${Y(i/4)}" stroke="#1d2a44" stroke-width="2"/>`;
  const sp=(S.T-5)/s.series.length;
  s.series.forEach((se,k)=>{const at=1.4+k*sp,d=Math.min(4,sp*.85),c=col(se.c||CY[k]),pts=se.pts;
    svg+=`<path id="${S.id}c${k}" d="${pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+' '+Y(p[1]).toFixed(1)).join('')}" fill="none" stroke="${c}" stroke-width="${se.dash?5:8}" stroke-linecap="round" stroke-linejoin="round" ${se.dash?'opacity=".9"':''} pathLength="1" stroke-dasharray="1" data-a="draw,${at.toFixed(2)},${d.toFixed(2)}"/><circle id="${S.id}h${k}" r="15" fill="#fff" opacity="0" style="filter:drop-shadow(0 0 12px ${c})"/>`;
    S.loop((t,g)=>{const p=eio(clamp((t-at)/d)),path=g('c'+k),L=path.getTotalLength(),pt=path.getPointAtLength(L*p),h=g('h'+k);h.setAttribute('cx',pt.x);h.setAttribute('cy',pt.y);h.setAttribute('opacity',t>at?1:0);h.setAttribute('r',13+Math.sin(t*5)*3)})});
  let html=`<svg class="lay">${svg}</svg>`+box('',px,py+ph+16,pw,0,s.xl||'',`fade,1`,'text-align:center;font-size:27px;color:#8fa3bf;')
   +box('',px-470,py+ph/2-20,800,0,s.yl||'',`fade,1`,'text-align:center;font-size:27px;color:#8fa3bf;transform:rotate(-90deg);').replace('data-a="fade,1"','')
   +(s.marks||[]).map(m=>box('',X(m.x)+(m.dx||18),Y(m.y)+(m.dy||-60),m.w||420,0,m.t,`pop,${(m.at*S.T).toFixed(2)},.5`,`font-size:30px;font-weight:750;color:${col(m.c||'amber')};line-height:1.15;`)
     +`<svg class="lay"><circle cx="${X(m.x)}" cy="${Y(m.y)}" r="14" fill="none" stroke="${col(m.c||'amber')}" stroke-width="5" data-a="pop,${(m.at*S.T).toFixed(2)},.5"/></svg>`).join('');
  if(s.legend!==false)html+=s.series.map((se,k)=>box('',px+pw+60,Y0+20+k*200,CW-pw-170,0,`<div style="width:70px;height:8px;border-radius:4px;background:${col(se.c||CY[k])};margin-bottom:14px"></div><div style="font-size:32px;font-weight:800;color:${col(se.c||CY[k])}">${se.l||''}</div><div style="font-size:25px;color:#c9d6ea;line-height:1.3">${se.d||''}</div>`,`right,${(1.4+k*sp).toFixed(2)}`)).join('');
  return html;
};
B.scatter=(s,S)=>{
  const px=X0+110,py=Y0+10,pw=s.side?1050:CW-220,ph=CH-90,X=v=>px+v*pw,Y=v=>py+ph-v*ph,r=rng(s.seed||7),tm=s.still?1:S.T*.42;let svg='',k=0;
  svg+=`<line x1="${px}" y1="${py+ph}" x2="${px+pw}" y2="${py+ph}" stroke="#5a6f93" stroke-width="4"/><line x1="${px}" y1="${py+ph}" x2="${px}" y2="${py}" stroke="#5a6f93" stroke-width="4"/>`;
  const gs=()=>{let u=0;for(let i=0;i<6;i++)u+=r();return(u-3)/1.2};const dots=[];
  s.groups.forEach((G,gi)=>{for(let i=0;i<G.n;i++){let a=gs(),b=gs(),tx,ty;if(G.r!=null){tx=G.cx+a*G.sx;ty=G.cy+(G.r*a+Math.sqrt(1-G.r*G.r)*b)*G.sy}else{tx=G.cx+a*G.sx;ty=G.cy+b*G.sy}
    dots.push({x:.06+r()*.88,y:.06+r()*.88,tx:clamp(tx,.02,.98),ty:clamp(ty,.02,.98),c:col(G.c||CY[gi]),id:k++})}
    if(G.l)svg+=`<ellipse cx="${X(G.cx)}" cy="${Y(G.cy)}" rx="${G.sx*pw*2.3}" ry="${G.sy*ph*2.3}" fill="${col(G.c||CY[gi])}18" stroke="${col(G.c||CY[gi])}" stroke-width="4" stroke-dasharray="14 10" data-a="pop,${(tm+1.8+gi*.4).toFixed(2)},.6"/>`});
  svg+=dots.map(d=>`<circle id="${S.id}d${d.id}" r="${s.r||10}" fill="#8fa3bf"/>`).join('');
  S.loop((t,g)=>{dots.forEach(d=>{const e=g('d'+d.id),a=pr(t,.5+d.id*(1.2/dots.length),.4),m=s.still?1:eio(pr(t,tm+(d.id%7)*.05,1.6)),wob=s.still?0:(1-m);
    e.setAttribute('cx',X(d.x+(d.tx-d.x)*m)+Math.sin(t*1.7+d.id)*6*wob);e.setAttribute('cy',Y(d.y+(d.ty-d.y)*m)+Math.cos(t*1.3+d.id*2)*6*wob);e.setAttribute('opacity',a);e.setAttribute('fill',m>.5?d.c:'#8fa3bf')})});
  return `<svg class="lay">${svg}</svg>`+box('',px,py+ph+16,pw,0,s.xl||'',`fade,.6`,'text-align:center;font-size:27px;color:#8fa3bf;')
   +`<div style="left:${px-470}px;top:${py+ph/2-20}px;width:800px;text-align:center;font-size:27px;color:#8fa3bf;transform:rotate(-90deg)">${s.yl||''}</div>`
   +s.groups.filter(G=>G.l).map((G,gi)=>box('',X(G.cx)+(G.lx||0)-200,Y(G.cy)-G.sy*ph*2.3-58+(G.ly||0),400,0,G.l,`pop,${(tm+2.1+gi*.4).toFixed(2)}`,`text-align:center;font-size:34px;font-weight:800;color:${col(G.c||CY[gi])};`)).join('')
   +(s.side?box('',px+pw+70,Y0+60,CW-pw-180,0,s.side,`right,${(tm+2).toFixed(2)}`,`font-size:34px;line-height:1.3;color:#dbe6f7;font-weight:600;border-left:8px solid ${S.acc};padding-left:26px;`):'');
};
B.stack=(s,S)=>{
  const n=s.levels.length,lh=CH/n,step=(S.T-3.5)/n,cx=X0+430;
  return s.levels.map((l,i)=>{const k=s.up?n-1-i:i,at=1+k*step,w=(l.w||1)*820,y=Y0+i*lh,c=col(l.c||CY[i%6]);
    S.fn(at,step,(p,t,g)=>{const on=t>=at&&t<at+step;g('l'+i).style.filter=on?`drop-shadow(0 0 26px ${c})`:'none'},null,true);
    return box('',cx-w/2,y+6,w,lh-12,`<div style="font-size:${lh<100?28:35}px;font-weight:800;color:#0a101c;text-align:center;line-height:1.1;padding:0 12px">${l.t}</div>`,`${s.up?'up':'pop'},${at.toFixed(2)},.7`,`background:${c};border-radius:14px;display:grid;place-items:center;`).replace('<div class=""',`<div id="${S.id}l${i}"`)
     +box('',cx+440,y+6,CW-880,lh-12,`<div style="font-size:${lh<100?24:28}px;line-height:1.3;color:#dbe6f7">${l.d||''}</div>`,`right,${(at+.25).toFixed(2)},.6`,`display:flex;align-items:center;border-left:6px solid ${c};padding-left:24px;`)}).join('');
};
B.units=(s,S)=>{
  const N=s.groups.reduce((a,g)=>a+g.n,0),aw=1040,cols=s.cols||Math.ceil(Math.sqrt(N*aw/CH)),rows=Math.ceil(N/cols),cell=Math.min(aw/cols,CH/rows,120),r=cell*.36,gs=(S.T-4.5)/s.groups.length;let svg='',k=0;const ox=X0+(aw-cols*cell)/2,oy=Y0+(CH-rows*cell)/2;
  s.groups.forEach((G,gi)=>{const tg=2.6+gi*gs,c=col(G.c||CY[gi]),start=k;
    for(let i=0;i<G.n;i++,k++){const x=ox+(k%cols+.5)*cell,y=oy+(Math.floor(k/cols)+.5)*cell;svg+=`<circle id="${S.id}u${k}" cx="${x}" cy="${y}" r="${r}" fill="#2a3a57" data-a="pop,${(.5+k*(1.6/N)).toFixed(3)},.4"/>`}
    S.loop((t,g)=>{for(let i=0;i<G.n;i++){const on=t>=tg+i*(Math.min(1.2,gs*.6)/G.n);const e=g('u'+(start+i));e.setAttribute('fill',on?c:'#2a3a57');e.setAttribute('r',on?r*(1+.25*Math.max(0,1-(t-tg-i*(Math.min(1.2,gs*.6)/G.n))*3)):r)}
      g('n'+gi).textContent=(G.pre||'')+fmt((G.show!=null?G.show:G.n)*eo(pr(t,tg,1)))+(G.suf||'')})});
  const lh=Math.min(150,CH/s.groups.length);
  return `<svg class="lay">${svg}</svg>`+s.groups.map((G,gi)=>box('',X0+aw+60,Y0+gi*lh+(CH-lh*s.groups.length)/2,CW-aw-60,lh-16,`<div class="big" style="font-size:${lh<110?58:76}px;color:${col(G.c||CY[gi])};min-width:${s.nw||150}px" id="${S.id}n${gi}">0</div><div style="font-size:${lh<110?25:29}px;line-height:1.25;color:#dbe6f7"><b style="color:${col(G.c||CY[gi])}">${G.l}</b>${G.d?'<br>'+G.d:''}</div>`,`right,${(2.6+gi*gs).toFixed(2)}`,'display:flex;gap:22px;align-items:center;')).join('');
};
B.verdicts=(s,S)=>{
  const n=s.items.length,rh=Math.min(130,CH/n),step=(S.T-2.5)/n;
  return s.items.map((it,i)=>{const y=Y0+i*rh+(CH-n*rh)/2,at=.9+i*step,c=it.c?col(it.c):it.ok?C.green:C.red,lab=it.lab||(it.ok?(s.yes||'Yes'):(s.no||'No'));
    S.fn(at+step*.5,.5,(p,t,g)=>{g('r'+i).style.borderColor=p>0?c:'#26344d'});
    return box('',X0,y+8,900,rh-16,`<span>${it.t}</span>`,`left,${at.toFixed(2)},.6`,`display:flex;align-items:center;padding:0 30px;font-size:${rh<110?27:31}px;line-height:1.2;font-weight:600;background:#101a2c;border:3px solid #26344d;border-radius:16px;`).replace('<div class=""',`<div id="${S.id}r${i}"`)
     +box('stamp',X0+930,y+rh/2-36,s.sw||230,72,lab,`stamp,${(at+step*.5).toFixed(2)},.35`,`--c:${c};font-size:${lab.length>9?24:32}px;`)
     +box('',X0+930+(s.sw||230)+30,y+8,CW-960-(s.sw||230),rh-16,it.why||'',`fade,${(at+step*.5+.3).toFixed(2)},.5`,`display:flex;align-items:center;font-size:${rh<110?23:26}px;line-height:1.25;color:#c9d6ea;`)}).join('');
};
B.quote=(s,S)=>{
  const words=s.text.split(' ');let hi=false;
  S.loop((t,g)=>{g('ln').style.width=(clamp((t-.3)/(S.T-2))*900)+'px'});
  return box('q',210,Y0-20,1500,CH-60,`<div>${words.map((w,i)=>{let o='';if(w.startsWith('*')){hi=true;w=w.slice(1)}const end=w.endsWith('*')||/\*[.,;:!?]$/.test(w);w=w.replace('*','');o=`<span data-a="up,${(.5+i*.26).toFixed(2)},.5"${hi?` style="color:${S.acc}"`:''}>${w} </span>`;if(end)hi=false;return o}).join('')}</div>`,'','display:grid;place-items:center;')
   +`<div id="${S.id}ln" style="left:510px;top:${Y0+CH-40}px;height:8px;border-radius:4px;background:${S.acc};width:0"></div>`
   +(s.by?box('',210,Y0+CH-10,1500,0,s.by,`fade,${(.5+words.length*.26).toFixed(2)}`,'text-align:center;font-size:30px;color:#8fa3bf;'):'');
};
B.recap=(s,S)=>{
  const n=s.items.length,cols=n<=3?n:Math.ceil(n/2),rows=n<=3?1:2,gap=26,w=(CW-gap*(cols-1))/cols,h=(CH-gap*(rows-1))/rows;
  return s.items.map((it,i)=>{const c=col(it.c||CY[i%6]),at=.8+i*((S.T-4)/n);
    return box('card',X0+(i%cols)*(w+gap),Y0+Math.floor(i/cols)*(h+gap),w,h,`<div class="bar"></div><svg width="54" height="54" viewBox="0 0 54 54" style="margin-bottom:12px"><circle cx="27" cy="27" r="24" fill="${c}"/><path d="M15 28l8 8 16-17" fill="none" stroke="#0a101c" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" pathLength="1" stroke-dasharray="1" data-a="draw,${(at+.5).toFixed(2)},.5"/></svg><h3 style="font-size:35px">${it.t}</h3><p style="font-size:26.5px">${it.d}</p>`,`flip,${at.toFixed(2)},.7`,`--c:${c}`)}).join('');
};
B.outro=(s,S)=>{
  S.loop((t,g)=>{g('ar').style.transform=`translateX(${Math.sin(t*3)*14}px)`});
  return box('',120,300,1680,0,s.line||'That’s the chapter.','up,.4','font-size:54px;font-weight:700;color:#c9d6ea;text-align:center;')
   +(s.next?box('',360,430,1200,300,`<div style="font-size:28px;letter-spacing:.22em;text-transform:uppercase;color:#8fa3bf;font-weight:600;margin-bottom:18px">Next up</div><div style="font-size:66px;font-weight:800;line-height:1.1;color:${S.acc}">${s.next}&nbsp;<span id="${S.id}ar" style="display:inline-block">→</span></div>`,'pop,1.4,.8',`border:3px solid ${S.acc};border-radius:28px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:30px;background:#101a2c;`):`<span id="${S.id}ar"></span>`)
   +box('',120,820,1680,0,SPEC.credit,'fade,2.6','text-align:center;font-size:26px;color:#8fa3bf;');
};

/* ---------- assemble ---------- */
const stage=document.getElementById('stage'),scenes=[];let total=0;
SPEC.scenes.forEach((s,i)=>{
  const caps=s.cap||[],T=s.dur||Math.max(DUR[s.type](s),caps.reduce((a,c)=>a+2.2+c.replace(/<[^>]+>/g,'').length*.052,1.2));
  const S={id:'s'+i+'_',T,acc:col(s.acc||CY[i%5]),fns:[],anims:[],memo:{}};
  S.fn=(at,dur,f,ease,always)=>S.fns.push({at,dur,f,always});S.loop=f=>S.fns.push({loop:1,f});
  const el=document.createElement('div');el.className='scene';el.style.setProperty('--acc',S.acc);
  let html=B[s.type](s,S);
  if(s.type!=='title'&&s.type!=='outro'){html+=`<div class="kick" data-a="left,.1,.5"><i></i>${s.kick||SPEC.kick}</div>`+(s.title?`<div class="h" data-a="up,.2,.7">${s.title}</div>`:'')}
  const cw=(S.T-1)/Math.max(1,caps.length);
  caps.forEach((c,k)=>{const at=.5+k*cw;let wi=0;const parts=c.split(/(<b>|<\/b>)/);let inb=false,out='';parts.forEach(p=>{if(p==='<b>'){inb=true;return}if(p==='</b>'){inb=false;return}p.split(/(\s+)/).forEach(w=>{if(!w)return;if(/^\s+$/.test(w)){out+=' ';return}if(/^[.,;:!?)\u2026]+$/.test(w)&&out.endsWith('</span>')){out=out.slice(0,-7)+w+'</span>';return}out+=`<span data-w="${wi++}">${inb?'<b>'+w+'</b>':w}</span>`})});
    html+=`<div class="cap" id="${S.id}cap${k}"><div>${out}</div></div>`;
    S.loop((t,g)=>{const e=g('cap'+k),vis=t>=at-.05&&t<at+cw;e.style.display=vis?'flex':'none';if(!vis)return;const ws=e._w||(e._w=e.querySelectorAll('span'));const sp=Math.min(.16,cw*.45/ws.length);
      for(let j=0;j<ws.length;j++){const p=eo(pr(t,at+j*sp,.3));ws[j].style.opacity=p;ws[j].style.transform=`translateY(${(1-p)*14}px)`}e.style.opacity=k<caps.length-1?1-pr(t,at+cw-.3,.25):1})});
  el.innerHTML=html;stage.appendChild(el);
  S.g=id=>S.memo[id]||(S.memo[id]=document.getElementById(S.id+id));
  el.querySelectorAll('[data-a]').forEach(e=>{const a=e.dataset.a.split(',');if(!a[0])return;S.anims.push({el:e,k:a[0],at:+a[1]||0,dur:+a[2]||.7,base:e.style.transform||''})});
  scenes.push({S,el,start:total,T});total+=T;
});
const prog=document.getElementById('prog');scenes.forEach(sc=>{if(sc.start){const u=document.createElement('u');u.style.left=(sc.start/total*100)+'%';prog.appendChild(u)}});
const pfill=prog.querySelector('i'),bgGrid=document.querySelector('#bg .grid'),blobs=document.querySelectorAll('#bg .blob'),mark=document.getElementById('mark');

function applyA(a,t){const p=clamp((t-a.at)/a.dur),e=a.el.style,o=eo(p);
  switch(a.k){
    case'up':e.opacity=o;e.transform=`${a.base} translateY(${(1-o)*46}px)`;break;
    case'left':e.opacity=o;e.transform=`${a.base} translateX(${(o-1)*70}px)`;break;
    case'right':e.opacity=o;e.transform=`${a.base} translateX(${(1-o)*70}px)`;break;
    case'fade':e.opacity=o;break;
    case'pop':e.opacity=clamp(p*4);e.transform=`${a.base} scale(${p<=0?.3:.3+.7*back(p)})`;break;
    case'draw':e.strokeDashoffset=1-eio(p);e.opacity=p>0?(a.el.getAttribute('opacity')||1):0;break;
    case'flip':e.opacity=clamp(p*3);e.transform=`perspective(1400px) rotateX(${(1-o)*-85}deg) translateY(${(1-o)*40}px)`;break;
    case'stamp':e.opacity=p>0?1:0;e.transform=`scale(${3.2-2.2*o}) rotate(${-7+((1-o)*-14)}deg)`;break;
  }}
let cur=-1;
function render(T){
  T=clamp(T,0,total-.001);let i=scenes.findIndex(sc=>T<sc.start+sc.T);if(i<0)i=scenes.length-1;
  if(i!==cur){scenes.forEach((sc,k)=>sc.el.style.display=k===i?'block':'none');cur=i}
  const sc=scenes[i],S=sc.S,t=T-sc.start,last=i===scenes.length-1;
  const pin=eo(pr(t,0,.55)),pout=last?0:eio(pr(t,sc.T-.45,.45));
  sc.el.style.opacity=pin*(1-pout);sc.el.style.transform=`translateX(${(1-pin)*90-pout*90}px) scale(${1+.015*(t/sc.T)})`;
  S.anims.forEach(a=>applyA(a,t));
  S.fns.forEach(f=>{if(f.loop)f.f(t,S.g);else if(f.always||t>=f.at)f.f(eo(clamp((t-f.at)/f.dur)),t,S.g)});
  pfill.style.width=(T/total*100)+'%';
  bgGrid.style.transform=`translate(${-(T*9)%80}px,${-(T*5)%80}px)`;
  blobs[0].style.transform=`translate(${Math.sin(T*.21)*260}px,${Math.cos(T*.17)*160}px)`;blobs[0].style.background=S.acc;
  blobs[1].style.transform=`translate(${Math.cos(T*.19)*240}px,${Math.sin(T*.23)*180}px)`;
  mark.textContent=String(i+1).padStart(2,'0')+' / '+String(scenes.length).padStart(2,'0');
}
/* ---------- player ---------- */
const q=new URLSearchParams(location.search);let T=+q.get('t')||0,playing=q.get('paused')==null,lastTs=0;
const ui=document.getElementById('ui'),seek=document.getElementById('seek'),btn=document.getElementById('pp'),tm=document.getElementById('tm');seek.max=total;
const mmss=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
function fit(){const k=Math.min(innerWidth/W,innerHeight/H);stage.style.transform=`translate(-50%,-50%) scale(${k})`}
addEventListener('resize',fit);fit();
function frame(ts){if(playing){if(lastTs)T+=Math.min(.1,(ts-lastTs)/1000);if(T>=total){T=total-.001;playing=false}}lastTs=ts;render(T);seek.value=T;tm.textContent=mmss(T)+' / '+mmss(total);btn.textContent=playing?'Pause':(T>=total-.01?'Replay':'Play');requestAnimationFrame(frame)}
function toggle(){if(T>=total-.01)T=0;playing=!playing}
btn.onclick=toggle;seek.oninput=()=>{T=+seek.value};
document.getElementById('rs').onclick=()=>{T=0;playing=true};
document.getElementById('fs').onclick=()=>{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()};
let clean=q.get('clean')!=null,hideTimer;function setClean(v){clean=v;document.body.classList.toggle('clean',v);ui.classList.toggle('hide',v)}
setClean(clean);
addEventListener('mousemove',()=>{if(clean)return;ui.classList.remove('hide');clearTimeout(hideTimer);hideTimer=setTimeout(()=>ui.classList.add('hide'),2500)});
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k===' '){e.preventDefault();toggle()}else if(k==='r'){T=0;playing=true}else if(k==='f')document.getElementById('fs').onclick();else if(k==='c')setClean(!clean);
  else if(k==='arrowright'){const n=scenes.find(sc=>sc.start>T+.05);T=n?n.start:T}else if(k==='arrowleft'){const p=[...scenes].reverse().find(sc=>sc.start<T-1);T=p?p.start:0}});
window.__seek=t=>{T=t;playing=false;render(T)};window.__total=total;window.__scenes=scenes.map(s=>[s.start,s.T]);
requestAnimationFrame(frame);
})();
