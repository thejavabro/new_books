/* Chapter list and helpers shared by every animated page of this book. */
const BOOK='Release It!',KICK='Release It!';
const CREDIT='Based on Release It!, 2nd edition, by Michael T. Nygard · original visual summary';
const ORDER=[['ch01-living-in-production','Chapter 1','Living in Production'],['ch02-airline-case-study','Chapter 2','The Exception That Grounded an Airline'],['ch03-stabilize-your-system','Chapter 3','Stabilize Your System'],['ch04a-antipatterns-integration','Chapter 4 · Part one','Stability Antipatterns: Points of Contact'],['ch04b-antipatterns-scale','Chapter 4 · Part two','Stability Antipatterns: Scale and Slowness'],['ch05a-patterns-containment','Chapter 5 · Part one','Stability Patterns: Contain the Damage'],['ch05b-patterns-flow','Chapter 5 · Part two','Stability Patterns: Control the Flow'],['ch06-black-friday','Chapter 6','Case Study: Black Friday'],['ch07-foundations','Chapter 7','Foundations'],['ch08-processes-on-machines','Chapter 8','Processes on Machines'],['ch09-interconnect','Chapter 9','Interconnect'],['ch10-control-plane','Chapter 10','Control Plane'],['ch11-security','Chapter 11','Security'],['ch12-13-design-for-deployment','Chapters 12–13','Design for Deployment'],['ch14-handling-versions','Chapter 14','Handling Versions'],['ch15-trampled-case-study','Chapter 15','Trampled by Your Own Customers'],['ch16-adaptation','Chapter 16','Adaptation'],['ch17-chaos-engineering','Chapter 17','Chaos Engineering']];
const line=(n,f)=>Array.from({length:n+1},(_,i)=>[i/n,f(i/n)]);
const SP=(g,b,t)=>({type:'versus',title:t||'Strengths and weaknesses',a:{h:'Strengths',c:'green',items:g},b:{h:'Weaknesses',c:'red',items:b}});
const VS=(title,ah,ai,bh,bi,cap,mid,ac,bc)=>({type:'versus',title,mid:mid||'VS',a:{h:ah,c:ac||'red',items:ai},b:{h:bh,c:bc||'green',items:bi},cap:cap||[]});
const PT=(title,items,cap)=>({type:'points',title,items:items.map(x=>({t:x[0],d:x[1]||'',c:x[2]})),cap:cap||[]});
const PL=(title,stages,cap,o)=>Object.assign({type:'pipeline',title,stages:stages.map(x=>({t:x[0],d:x[1]||'',c:x[2]})),cap:cap||[]},o||{});
const ST=(title,levels,cap,o)=>Object.assign({type:'stack',title,levels:levels.map(x=>({t:x[0],d:x[1]||'',c:x[2],w:x[3]||1})),cap:cap||[]},o||{});
const BR=(title,items,cap,o)=>Object.assign({type:'bars',title,items:items.map(x=>({l:x[0],v:x[1],txt:x[2],c:x[3],suf:x[4]})),cap:cap||[]},o||{});
const VD=(title,items,cap,o)=>Object.assign({type:'verdicts',title,items:items.map(x=>({t:x[0],ok:x[1],why:x[2],lab:x[3],c:x[4]})),cap:cap||[]},o||{});
const QT=(title,text,by,acc)=>({type:'quote',title,text,by,acc});
const RC=(n,items)=>({type:'recap',title:(/^[0-9]/.test(n)?'Chapter '+n:n)+' on one screen',items:items.map(x=>({t:x[0],d:x[1]}))});
function CH(c){
  const i=ORDER.findIndex(o=>o[0]===c.slug),o=ORDER[i],nx=ORDER[i+1];
  const scenes=[{type:'title',n:c.n,part:c.part||BOOK,title:o[2],sub:c.sub,acc:'blue'}].concat(c.scenes,[{type:'outro',line:c.end,next:nx?nx[1]+' \u00b7 '+nx[2]:null,acc:'teal'}]);
  window.SPEC={kick:KICK+' \u00b7 '+o[1],credit:CREDIT,scenes};
}
